package tests;

public class UserTests {
}
