package tests;

public class LoginTests {
}
